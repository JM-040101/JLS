# Recipes Module - Recipe Management & Database

## Purpose
Comprehensive recipe database with CRUD operations, dietary filtering, and integration with meal planning system.

## Features

### Recipe Database Management
#### Constraints
- **Must** support user-created and curated recipes
- **Must** implement full-text search on title, ingredients, and tags
- **Must** store structured recipe data (ingredients, instructions, nutrition)
- *Should* support recipe ratings and reviews
- **Must** enforce dietary tagging consistency

#### State Flow
- Input: Recipe data (title, ingredients, instructions, dietary_tags)
- Process: Validate format → Check dietary tags → Store with metadata
- Output: Recipe record with unique ID and search indexing

### Recipe CRUD Operations
#### Constraints
- **Must** allow users to create, read, update, delete their own recipes
- **Must** support recipe sharing between family members
- **Must** validate ingredient list format and quantities
- *Should* auto-suggest dietary tags based on ingredients
- **Must** maintain recipe version history for edits

#### Permission Matrix
- **Create**: Family Admin, Family Member (own recipes only)
- **Read**: All roles (with RLS filtering)
- **Update**: Creator only, or Family Admin
- **Delete**: Creator only, or Family Admin

### Dietary Filtering System
#### Constraints
- **Must** support common dietary restrictions: vegetarian, vegan, gluten-free, dairy-free, nut-free, keto, paleo
- **Must** flag potential allergens prominently
- **Must** filter recipes based on user's DietaryProfile
- *Should* suggest recipe modifications for dietary needs
- **Must** validate dietary tags against ingredient list

#### Supported Dietary Tags