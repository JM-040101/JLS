# Authentication Module – User Management & Security

## Scope
This file defines authentication rules, user roles, and security policies for FitTrack Pro. All auth-related features must reference this module.

## Features

### User Registration
#### Constraints
- **Must** use Supabase Auth for all authentication flows
- **Must** validate email addresses before account activation  
- **Must** enforce password requirements: 8+ chars, 1 uppercase, 1 number
- *Should* support OAuth providers (Google, Apple, Facebook)
- *Should* implement progressive profiling during onboarding

#### State Flow