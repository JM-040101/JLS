# Auth Module - User Authentication & Authorization

## Purpose
Secure user authentication with Supabase Auth, supporting email/password and social logins, with role-based access control for family members.

## Features

### User Registration
#### Constraints
- **Must** validate email format and password strength (8+ chars, mixed case, numbers)
- **Must** support social login (Google, Apple)
- *Should* defer email verification until first meal plan creation
- **Must** create default DietaryProfile on signup

#### State Flow
- Input: email, password, optional social provider
- Process: Supabase auth.signUp() → create user record → create default dietary profile
- Output: JWT token + user session

### User Authentication
#### Constraints
- **Must** use JWT tokens with 30-minute expiry
- **Must** implement secure token refresh
- **Must** support "Remember Me" for 30-day sessions
- *Should* implement rate limiting (5 attempts per 10 minutes)

#### State Flow
- Input: credentials or social provider
- Process: Supabase auth.signInWithPassword() → validate → return session
- Output: JWT token + user profile data

### Role-Based Access Control
#### Constraints
- **Must** support three roles: Family Admin, Family Member, Guest
- **Must** enforce permissions at API and RLS level
- **Family Admin**: All permissions on account data
- **Family Member**: Create/edit own content, view family content
- **Guest**: Read-only access to shared recipes only

#### Permission Matrix
- **Recipes**: Admin/Member (CRUD own), Guest (Read shared only)
- **MealPlans**: Admin (CRUD all), Member (CRUD own), Guest (none)
- **Billing**: Admin only
- **Settings**: Admin only

### Session Management
#### Constraints
- **Must** implement secure logout with token invalidation
- **Must** handle concurrent sessions gracefully
- *Should* auto-logout inactive sessions after 24 hours
- **Must** protect against CSRF attacks

### Multi-Factor Authentication (Optional)
#### Constraints
- *Should* support TOTP-based MFA for Family Admins
- *Should* allow MFA bypass for trusted devices (30 days)
- **Must** provide recovery codes for MFA reset

## Database Schema