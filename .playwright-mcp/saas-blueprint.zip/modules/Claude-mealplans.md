# MealPlans Module - Weekly Meal Planning System

## Purpose
Generate, manage, and track weekly meal plans using AI-powered recipe selection with user customization and family coordination capabilities.

## Features

### Meal Plan Generation
#### Constraints
- **Must** generate 7-day meal plans (breakfast, lunch, dinner)
- **Must** integrate with AI module for intelligent recipe selection
- **Must** consider user's DietaryProfile and family size
- **Must** avoid recipe repetition within 14-day window
- *Should* balance nutrition across the week
- **Must** support manual recipe substitution after generation

#### State Flow
- Input: week_start_date, DietaryProfile, family_size, preferences
- Process: Call AI module → Validate recipe availability → Create MealPlan record → Generate associated meals
- Output: Complete MealPlan with 21 meals organized by day/meal_type

### Meal Plan Customization
#### Constraints
- **Must** allow users to swap individual meals
- **Must** support saving meal plan templates for reuse  
- **Must** accommodate last-minute recipe changes
- *Should* suggest alternative recipes when swapping meals
- **Must** recalculate shopping list when meals are modified

#### Customization Options
- Swap individual recipes within meal plan
- Mark meals as "favorites" for future suggestions
- Adjust serving sizes for household changes
- Skip meals (eating out, leftovers)
- Duplicate successful meal plans for future weeks

### Meal Plan Status Management
#### Constraints
- **Must** track meal plan status: draft → active → completed → archived
- **Must** allow only one active meal plan per user per week
- **Must** automatically archive completed meal plans after 30 days
- *Should* support meal plan sharing within families

#### Status Workflow