# SmartChef - AI-Powered Meal Planning SaaS

SmartChef leverages AI to streamline meal planning, generating weekly meal plans and shopping lists based on dietary profiles and pantry items, minimizing food waste and planning stress.

## 🎯 Target Users
Working parents (30-45 years old) with 2-4 family members who value time-saving solutions and want to reduce meal planning from 2-3 hours to under 5 minutes.

## ⚡ Quick Start
1. Clone repository
2. `npm install`
3. Configure `.env` with Supabase and OpenAI credentials
4. `npm run dev`
5. Visit `http://localhost:3000`

## 🏗️ Tech Stack
- **Frontend**: Next.js 14 + Tailwind CSS
- **Backend**: Next.js API Routes + Serverless Functions
- **Database**: PostgreSQL on Supabase
- **Auth**: Supabase Auth
- **Payments**: Stripe
- **AI**: OpenAI GPT-4/3.5
- **Hosting**: Vercel

## 📁 Project Structure