# SmartChef - Technical Specification for Claude Code

## Project Overview
SmartChef is an AI-powered meal planning SaaS application that generates personalized weekly meal plans and automated shopping lists for busy families. The application reduces meal planning time from 2-3 hours to under 5 minutes while minimizing food waste and grocery overspending.

## Core Architecture Summary

### Technology Stack
- **Frontend**: Next.js 14 with App Router, Tailwind CSS, shadcn/ui components
- **Backend**: Next.js API Routes (serverless), Supabase PostgreSQL
- **Authentication**: Supabase Auth with JWT tokens
- **Payments**: Stripe subscriptions with webhook handling
- **AI**: GPT-4 for meal planning, GPT-3.5 for simple suggestions
- **Deployment**: Vercel for hosting, GitHub Actions for CI/CD

### Architecture Pattern
Monolithic architecture ideal for MVP, with clear module separation for future microservices evolution.

## Module Structure

### Core Modules
- **Authentication Module** → [modules/auth-module.md]
- **API Module** → [modules/api-module.md]
- **Database Module** → [modules/database-module.md]
- **UI Module** → [modules/ui-module.md]
- **Payments Module** → [modules/payments-module.md]

## Critical Constraints and Rules

### Security Requirements
- **Authentication**: All API endpoints require valid JWT tokens
- **Authorization**: Role-based access control (Admin, Member, Guest)
- **Data Isolation**: Row Level Security (RLS) enforced on all user data
- **Input Validation**: Strict validation on all user inputs using Zod schemas
- **Rate Limiting**: API rate limiting to prevent abuse (100 requests/minute per user)

### Database Constraints
- **Multi-tenancy**: Shared database with user_id filtering
- **RLS Policies**: Every table with user data must have RLS policies
- **Indexing**: Primary keys, foreign keys, and user_id fields must be indexed
- **Migrations**: All schema changes through versioned migrations

### AI Integration Constraints
- **Cost Control**: Rate limiting at 50 AI requests per user per day
- **Fallback**: Always provide non-AI alternatives when AI fails
- **Content Safety**: All AI-generated content must be moderated
- **Context Management**: Keep AI prompts under 2000 tokens

### Performance Requirements
- **Page Load**: <2 seconds for all pages
- **API Response**: <500ms for non-AI endpoints, <10s for AI endpoints
- **Database Queries**: All queries must use proper indexes
- **Caching**: Redis caching for frequently accessed data

## MCP Server Requirements

### Required MCP Servers