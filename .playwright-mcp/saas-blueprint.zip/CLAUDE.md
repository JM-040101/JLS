# SmartChef - AI-Powered Meal Planning SaaS

**Objective**: Reduce weekly meal planning time from 2-3 hours to under 5 minutes through AI-generated meal plans and automated shopping lists.

## Modules
- **Auth** – [Claude-auth.md](Claude-auth.md)
- **AI** – [Claude-ai.md](Claude-ai.md) 
- **Recipes** – [Claude-recipes.md](Claude-recipes.md)
- **MealPlans** – [Claude-mealplans.md](Claude-mealplans.md)
- **ShoppingLists** – [Claude-shoppinglists.md](Claude-shoppinglists.md)
- **PantryTracking** – [Claude-pantry.md](Claude-pantry.md)
- **Billing** – [Claude-billing.md](Claude-billing.md)
- **UI** – [Claude-ui.md](Claude-ui.md)

## Global Constraints
1. **All modules must use Supabase RLS for data isolation**
2. **AI costs must stay under $1500/month for 5000 users**
3. **Page loads must be <2 seconds, API responses <500ms**
4. **Mobile-first responsive design required**
5. **GDPR/CCPA compliance mandatory**

## Core Primitives
- **Recipe**: title, ingredients[], dietary_tags[], instructions, created_by
- **MealPlan**: user_id, week_start_date, recipes[], status
- **ShoppingList**: meal_plan_id, items[], generated_at
- **PantryItem**: user_id, item_name, quantity, expiry_date
- **DietaryProfile**: user_id, restrictions[], preferences[]

## State Flow
User creates DietaryProfile → Generates MealPlan (AI-filtered recipes) → Auto-generates ShoppingList (minus PantryItems) → User can execute grocery delivery

## Success Metrics
- **Activation**: First meal plan generated within 7 days
- **Engagement**: >2 meal plans per month per user  
- **Retention**: 70% of users active after 30 days
- **Performance**: 99.5% uptime, <2s page loads

## Metadata