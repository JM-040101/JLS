# FitTrack Pro – Intelligent Fitness Journey Platform

<documents>
# ClaudeOps: Use 4-part prompts (Objective, Context, Constraints, Output); map outputs to file paths.
# DevBook: Put Context before instructions; use heading hierarchy for memory structure.
</documents>

## Objective
Create a comprehensive SaaS fitness tracking platform that solves the lack of structured, engaging, and personalized fitness tracking through customizable workout routines, progress visualization, and AI-powered recommendations.

## Modules
- **Authentication** – [Claude-auth.md](Claude-auth.md) - User registration, login, role management
- **Workouts** – [Claude-workouts.md](Claude-workouts.md) - Exercise library, workout plans, session tracking
- **Progress** – [Claude-progress.md](Claude-progress.md) - Goal setting, progress logging, analytics dashboard
- **Billing** – [Claude-billing.md](Claude-billing.md) - Stripe integration, subscription management
- **UI Components** – [Claude-ui.md](Claude-ui.md) - Design system, accessibility, responsive layouts
- **AI Integration** – [Claude-ai.md](Claude-ai.md) - Workout personalization, recommendation engine

## Global Constraints
1. **Security First** - All modules must implement row-level security, HTTPS encryption, and GDPR compliance
2. **Mobile-First Design** - Every component must work flawlessly on mobile devices with touch targets ≥44px  
3. **Performance Standards** - Pages must load in <3 seconds, 99.5% uptime target
4. **Accessibility** - WCAG 2.1 AA compliance across all interfaces
5. **Data Privacy** - EU data stays in EU, proper consent management, audit trails

## User Journey & Activation
### Onboarding Flow
1. **Fitness Quiz** - 5-7 questions about experience, goals, preferences
2. **Instant Plan Generation** - AI creates personalized workout plan
3. **Guided First Workout** - Interactive tutorial with progress tracking
4. **Aha Moment** - Visual progress after completing first workout

### Success Metrics
- **Activation Definition** - 2 workouts completed + 3 app visits in first week
- **Beta Validation** - 60% of users complete 3 workouts in first 2 weeks
- **Growth Targets** - 10K users Year 1, 100K by Year 3

## Tech Stack Configuration