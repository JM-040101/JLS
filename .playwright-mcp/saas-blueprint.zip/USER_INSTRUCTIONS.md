# How to Use This SmartChef Export Package

## 🎯 What This Export Contains

This export package contains everything needed to build SmartChef - an AI-powered meal planning SaaS application. The files are organized into a complete development workflow:

### Documentation Files
- **README.md** - High-level project overview and quick start guide
- **CLAUDE.md** - Complete technical specification for Claude Code workspace
- **USER_INSTRUCTIONS.md** - This file explaining how to use everything

### Module Documentation (modules/ folder)
- **auth-module.md** - Authentication system specifications
- **api-module.md** - Backend API architecture and endpoints
- **database-module.md** - Database schema and multi-tenancy setup
- **ui-module.md** - Frontend components and user interface
- **payments-module.md** - Stripe integration and subscription handling

### Implementation Prompts (prompts/ folder)
- **01-setup-project.md** - Initialize Next.js project and dependencies
- **02-setup-database.md** - Configure Supabase and database schema
- **03-setup-auth.md** - Implement authentication with Supabase Auth
- **04-create-api.md** - Build API endpoints and business logic
- **05-create-ui.md** - Develop user interface components
- **06-integrate-payments.md** - Set up Stripe payments and subscriptions
- **07-deploy.md** - Deploy to production on Vercel

## 🚀 How to Use This Export

### Step 1: Review Documentation
1. Start with **README.md** for project overview
2. Read **CLAUDE.md** thoroughly - this is your technical bible
3. Review each module file to understand the architecture

### Step 2: Setup Claude Code Workspace
1. Create a new project folder for SmartChef
2. Copy **CLAUDE.md** into your project root
3. Install required MCP servers (see MCP Requirements below)
4. Open the project in Claude Code

### Step 3: Follow Implementation Prompts
Execute the prompts **in sequential order**:
1. Start with `prompts/01-setup-project.md`
2. Complete each step fully before moving to the next
3. Check off all requirements in each prompt
4. Use the "Success Criteria" to validate completion

### Step 4: Development Workflow
- Reference module files when working on specific features
- Use CLAUDE.md as your primary technical reference
- Follow the constraints and patterns defined in each module

## 🛠 MCP Server Requirements

Before starting development, ensure these MCP servers are installed:

### Required MCP Servers
- **@modelcontextprotocol/server-supabase** - Database operations
- **@modelcontextprotocol/server-playwright** - E2E testing
- **@modelcontextprotocol/server-filesystem** - File management

### Installation Commands