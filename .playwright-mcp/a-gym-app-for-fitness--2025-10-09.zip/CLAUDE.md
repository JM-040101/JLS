# CLAUDE.md

This file provides guidance to Claude Code when building **gym app pro **.

## Project Overview

a gym app for fitness 

## Architecture & Stack

Based on your blueprint answers, here are the key technical decisions:

**What specific problem are you solving?**
Pain point: People struggle to stay consistent with fitness routines due to lack of structure, progress tracking, and accountability. Current solutions: Generic fitness apps lack personalization, gym memberships are expensive and intimidating, personal trainers are costly. What's broken: Most apps are either too simple (just tracking) or too complex (overwhelming), no middle ground for guided accountability

**What's the "job to be done" for your user?**
They hire our product when: They commit to getting fit but feel lost about where to start or how to progress safely. What they're accomplishing: Building a sustainable fitness habit with clear guidance and measurable progress. Success looks like: Consistent 3-4 workouts per week, visible strength/endurance improvements within 8 weeks, feeling confident in the gym

**Who is your Ideal Customer Profile (ICP)?**
Industry: Health & Fitness. Company size: Solo fitness enthusiasts (primary), Personal trainers (2-10 clients), Small gyms (11-50 members). Buyer persona: 25-45 year old professionals who value health, willing to invest in fitness tech. End user: Same as buyer - fitness-conscious individuals seeking structured workout guidance

**Have you validated this pain with real users?**
Customer interviews: 35 interviews with gym-goers and fitness enthusiasts. Key insights: 82% want guided workout plans they can customize, 71% need progress tracking with visual feedback, 65% would pay for accountability features. Prototype: Yes - built clickable Figma wireframes, tested with 12 beta users, 9/12 said they would use it daily

## Database Schema

**List all potential features you've considered**
Core: Workout plan generator, exercise library with videos, progress tracking dashboard, workout logging, goal setting. Social: Friend challenges, community feed, workout sharing, trainer marketplace. Advanced: AI form checker via camera, nutrition tracking, wearable device sync, custom exercise creation, rest day recommendations, injury prevention tips, video coaching calls, meal planning, supplement tracking, body measurement photos, 1RM calculator, periodization planning.

**How will you validate MVP success?**
Success metrics: 60% of users complete at least 3 workouts in first 2 weeks (retention signal), 40% weekly active users after month 1 (engagement), NPS score above 40 (product-market fit indicator). Validation method: Deploy to 50 beta users from interview pool, track usage analytics via Mixpanel, conduct 10 follow-up interviews after 4 weeks. Go/no-go decision: If retention hits 50%+ and feedback is positive, invest in V1.5 features. If below 40%, pivot feature set based on user feedback.

**What is the ONE core problem your MVP solves?**
Providing structured, customizable workout routines with simple progress tracking that keeps users accountable without overwhelming them. Users can select their fitness goal (strength, endurance, weight loss), get a personalized weekly workout plan, and log their completed sessions with automatic progress visualization.

**Which features are must-haves for MVP vs nice-to-haves?**
MVP Must-haves: User auth/profiles, 3 pre-built workout plans (beginner/intermediate/advanced), exercise library (50 exercises with text descriptions), simple workout logging (sets/reps/weight), basic progress dashboard (workouts completed, consistency streak). V1.5 Nice-to-haves: Exercise videos, custom workout creation, rest timer, workout history calendar, goal tracking with milestones, weekly progress reports. Post-V1.5: Social features, AI coaching, nutrition integration, wearable sync.

## Feature Implementation Plan

### Phase 1: Product Abstraction & Vision

**How should these primitives be named consistently?**
Workout: UI component=WorkoutCard, Database table=workouts, API endpoint=/api/workouts
ProgressLog: UI component=ProgressEntry, Database table=progress_logs, API endpoint=/api/progress
Goal: UI component=GoalTracker, Database table=fitness_goals, API endpoint=/api/goals

**How do your primitives relate to each other?**
One-to-many: One User has many Workouts, One Workout has many Exercise Sets
Many-to-many: Users can follow multiple Trainers, Trainers can have multiple Clients
One Goal can track multiple Progress Logs

**What's the core metaphor for your product?**
Fitness Journey - like a guided trail where users progress through workouts, track milestones, and unlock achievements along their path to better health

**What are the main "things" users will create or manipulate?**
Workouts, Progress Logs, Fitness Goals, Exercise Routines, Body Measurements. Users CREATE workout plans, LOG their exercises and reps, TRACK progress photos, SET fitness goals, and SHARE achievements with friends

**What are the possible states for your main primitive?**
Workout states: Draft → Scheduled → In Progress → Completed → Archived
Actions: Create (start new workout), Start (begin session), Log (record exercises), Complete (finish workout), Archive (remove from active list)


### Phase 2: Core Product Assumptions (CPA Layer)

**What type of data will you handle and which regulations apply?**
Data types: Personal (names, emails, profile photos), Health (body measurements, workout stats, progress photos). Regulations: GDPR compliance needed for EU users, general data privacy standards. Data storage: Any region, but EU users' data must stay in EU. No HIPAA required as we're fitness tracking not medical device

**Who's your initial target and what integrations do they need?**
Initial target: Self-serve fitness enthusiasts and small gym owners (SMBs). No single-tenant deployments initially. Integrations needed: Social login (Google, Apple), Fitness tracker APIs (Apple Health, Google Fit, Fitbit), Payment processing (Stripe), Optional: Strava, MyFitnessPal

**How many users/organizations do you expect in Year 1? Year 3?**
Year 1: 10,000 users (500 organizations like gyms/trainers). Year 3: 100,000 users (5,000 organizations). Usage will be bursty - peak hours 6-9am and 5-8pm on weekdays. Growth rate: 25% monthly for first 6 months, then 10% monthly

**What uptime commitment and support model will you provide?**
Uptime commitment: 99.5% (acceptable downtime for maintenance during off-peak hours 2-5am). Support model: Email support 9-5 EST for first year, expanding to chat support in Year 2. Scheduled maintenance windows acceptable with 48hr notice to users


### Phase 3: Audience & Customer Development

**What specific problem are you solving?**
Pain point: People struggle to stay consistent with fitness routines due to lack of structure, progress tracking, and accountability. Current solutions: Generic fitness apps lack personalization, gym memberships are expensive and intimidating, personal trainers are costly. What's broken: Most apps are either too simple (just tracking) or too complex (overwhelming), no middle ground for guided accountability

**What's the "job to be done" for your user?**
They hire our product when: They commit to getting fit but feel lost about where to start or how to progress safely. What they're accomplishing: Building a sustainable fitness habit with clear guidance and measurable progress. Success looks like: Consistent 3-4 workouts per week, visible strength/endurance improvements within 8 weeks, feeling confident in the gym

**Who is your Ideal Customer Profile (ICP)?**
Industry: Health & Fitness. Company size: Solo fitness enthusiasts (primary), Personal trainers (2-10 clients), Small gyms (11-50 members). Buyer persona: 25-45 year old professionals who value health, willing to invest in fitness tech. End user: Same as buyer - fitness-conscious individuals seeking structured workout guidance

**Have you validated this pain with real users?**
Customer interviews: 35 interviews with gym-goers and fitness enthusiasts. Key insights: 82% want guided workout plans they can customize, 71% need progress tracking with visual feedback, 65% would pay for accountability features. Prototype: Yes - built clickable Figma wireframes, tested with 12 beta users, 9/12 said they would use it daily


### Phase 4: MVP, V1.5 & Roadmap

**List all potential features you've considered**
Core: Workout plan generator, exercise library with videos, progress tracking dashboard, workout logging, goal setting. Social: Friend challenges, community feed, workout sharing, trainer marketplace. Advanced: AI form checker via camera, nutrition tracking, wearable device sync, custom exercise creation, rest day recommendations, injury prevention tips, video coaching calls, meal planning, supplement tracking, body measurement photos, 1RM calculator, periodization planning.

**How will you validate MVP success?**
Success metrics: 60% of users complete at least 3 workouts in first 2 weeks (retention signal), 40% weekly active users after month 1 (engagement), NPS score above 40 (product-market fit indicator). Validation method: Deploy to 50 beta users from interview pool, track usage analytics via Mixpanel, conduct 10 follow-up interviews after 4 weeks. Go/no-go decision: If retention hits 50%+ and feedback is positive, invest in V1.5 features. If below 40%, pivot feature set based on user feedback.

**What is the ONE core problem your MVP solves?**
Providing structured, customizable workout routines with simple progress tracking that keeps users accountable without overwhelming them. Users can select their fitness goal (strength, endurance, weight loss), get a personalized weekly workout plan, and log their completed sessions with automatic progress visualization.

**Which features are must-haves for MVP vs nice-to-haves?**
MVP Must-haves: User auth/profiles, 3 pre-built workout plans (beginner/intermediate/advanced), exercise library (50 exercises with text descriptions), simple workout logging (sets/reps/weight), basic progress dashboard (workouts completed, consistency streak). V1.5 Nice-to-haves: Exercise videos, custom workout creation, rest timer, workout history calendar, goal tracking with milestones, weekly progress reports. Post-V1.5: Social features, AI coaching, nutrition integration, wearable sync.


### Phase 5: User Flows & Onboarding

**How will users sign up?**
Multiple Methods

**What is the "aha moment" you want users to experience?**
Completing their first workout and seeing it automatically logged on their progress dashboard with a visual streak counter showing "Day 1". The moment they realize "I don't have to figure out what to do - the plan is already here, I just need to show up and track it" creates the emotional shift from overwhelmed to empowered.

**How will you guide new users to that aha moment?**
3-step onboarding: (1) Quick quiz - 3 questions: fitness goal, experience level, workout frequency preference (2 mins). (2) Instant plan generation - show personalized weekly plan immediately with first workout highlighted "Start here today" (30 seconds). (3) Guided first workout - interactive walkthrough showing how to log sets/reps, with celebration animation on completion (10 mins). Total time to aha: under 15 minutes from signup to first completed workout.

**What defines an "activated" user?**
User has completed at least 2 workouts within their first 7 days and returned to the app on 3+ separate days. This signals they've experienced the core value loop (plan → workout → log → see progress) multiple times and are building habit formation. Secondary indicator: user has customized at least one setting (plan difficulty, workout days, exercise swap).

**What might cause users to drop off before activation?**
Friction points: Onboarding quiz too long or asks intimidating questions (weight, body fat %), workout plans feel generic or don't match stated goals, first workout is too hard/easy causing discouragement, no reminder to come back after signup, unclear how to log exercises, too many app permissions requested upfront. Timing issues: Users sign up at night but plan starts "tomorrow" with no immediate action to take.


### Phase 6: UI/UX & Branding

**Which design framework fits your needs?**
Tailwind CSS with shadcn/ui components for rapid development and consistency. Mobile-first responsive design since 80% of users will access via phone at the gym. Component library includes: workout cards, progress charts, exercise list items, timer widgets. Design tokens: 8px spacing scale, consistent border-radius (8px for cards, 4px for buttons), motion design for celebrations/transitions.

**What's your brand personality?**
Motivating but not intimidating. Supportive coach rather than drill sergeant. Clean, modern, energetic. Tone: encouraging, straightforward, achievement-focused. Visual style: bold typography for workout names, plenty of whitespace to reduce cognitive load, celebratory micro-animations for milestones (confetti on streak achievements), progress-forward imagery (graphs going up, checkmarks completing).

**Describe your color scheme**
Primary: Vibrant orange (#FF6B35) for energy and action (CTAs, completed workouts). Secondary: Deep navy (#1A1D2E) for trust and professionalism (headers, text). Accent: Electric blue (#4ECDC4) for progress indicators and links. Neutrals: Light gray (#F7F7F7) backgrounds, dark gray (#333333) body text. Success green (#2ECC71) for achievements, alert red (#E74C3C) for rest days. High contrast ratios for text readability.

**What are your accessibility requirements?**
WCAG 2.1 AA compliance minimum. Specific needs: Large touch targets (48px minimum) for gym use with sweaty hands, high contrast text (4.5:1 ratio), screen reader support for visually impaired users, keyboard navigation for all interactive elements, no color-only indicators (use icons + color), captions for exercise videos, adjustable text size, reduced motion option for users sensitive to animations, workout timer with haptic feedback for users with hearing impairments.

**Which SaaS products inspire your UI?**
Strava for social motivation and clean activity feeds, Duolingo for gamification and streak mechanics, Linear for minimal UI and fast interactions, Notion for flexible card-based layouts, Apple Fitness+ for workout video presentation, MyFitnessPal for simple logging interfaces, Headspace for calming progress visualization, Superhuman for keyboard shortcuts and speed-focused UX.


### Phase 7: Tech Stack & Infrastructure

**What's your team situation?**
Solo developer

**Frontend preference**
Next.js 14 with App Router for server components and optimal performance. React for component library, TypeScript for type safety, Tailwind CSS + shadcn/ui for styling. React Query for data fetching/caching, Zustand for lightweight state management, Framer Motion for animations. Mobile-first responsive web app initially, with React Native wrapper (Capacitor) for future native apps if needed.

**Backend preference**
Next.js API routes for simple endpoints, Supabase for backend-as-a-service (auth, database, real-time subscriptions, storage). Edge functions for custom business logic. RESTful API design for workout CRUD operations. Background jobs via Supabase Edge Functions or Vercel Cron for daily workout reminders, weekly progress summaries.

**Database preference**
PostgreSQL via Supabase for relational data (users, workouts, exercises, logs). Schema: users table, workout_plans (templates), workout_sessions (user completions), exercise_library, progress_logs. Row-level security for user data isolation. Indexes on user_id, created_at for fast queries. Real-time subscriptions for live workout updates if training with friends.

**Hosting & deployment preference**
Vercel for Next.js frontend and API routes (automatic deployments, edge network, preview branches). Supabase cloud for database and backend services. CDN via Vercel Edge for static assets and images. Environment-based deployments: development (local), staging (preview branches), production (main branch). CI/CD via GitHub Actions for automated testing before deploy.

**Authentication approach**
Supabase Auth with multiple providers: email/password (primary), Google OAuth, Apple Sign-In (for iOS users). Magic link option for passwordless login. JWT tokens with refresh token rotation. Session management via HTTP-only cookies. Password reset via email, email verification required. Rate limiting on auth endpoints to prevent abuse.

**Payments provider**
Stripe for subscription billing. Single tier pricing ($9.99/month or $79/year). Stripe Checkout for payment collection, Stripe Customer Portal for subscription management. Webhooks for real-time subscription status updates. Trial period: 14-day free trial. Payment methods: credit/debit cards, Apple Pay, Google Pay. EU VAT compliance via Stripe Tax.


### Phase 8: Database Design & Multi-Tenancy

**What are the core resources you need to store?**
Users (profiles, preferences, subscription status), Workout Plans (templates with exercises, sets, reps, rest periods), Exercise Library (name, description, muscle groups, equipment, difficulty), Workout Sessions (user's completed workouts with timestamps), Exercise Logs (individual set performance: weight, reps, RPE), Goals (target metrics like weight, strength milestones), Progress Snapshots (periodic measurements, photos), Streaks (consecutive workout days).

**User-Organization relationship**
One organization per user

**Multi-tenancy approach**
Row-level security (RLS) with user_id on all user data tables. Single shared database with PostgreSQL policies enforcing data isolation. Each user owns their workout sessions, logs, and goals. Shared exercise library (global) with user-specific custom exercises. RLS policies: users can only SELECT/UPDATE/DELETE their own rows. Future consideration: gym/trainer accounts could be multi-tenant (one gym, many members).

**User roles needed**
MVP roles: Standard User (individual fitness enthusiast with full access to their own data). Future roles: Trainer (can view client workouts, assign plans, track progress), Gym Admin (manage multiple trainers and members), Premium User (access to advanced features like AI coaching). Role-based permissions handled via Supabase Auth user metadata and RLS policies checking user.role field.

**Data isolation requirements**
Strict user data isolation via RLS policies - users cannot access other users' workout sessions, logs, or progress data. Exercise library is globally readable but only admin-writable for curated exercises. Users can create private custom exercises visible only to them. No cross-user data leakage in queries. API endpoints validate user ownership before returning data. Future: Trainers can view clients only if explicit permission granted via trainer_client relationship table.


### Phase 9: Feedback Injection Loops

**Pre-launch validation approach**
Private beta with 50 users from customer interviews. Weekly check-ins via email asking: What worked? What frustrated you? What's missing? Offer 6 months free subscription for detailed feedback. Track beta user cohort separately in analytics to measure activation, retention, and feature usage. Run usability tests on onboarding flow with 5-10 new beta users watching screen recordings. Exit survey: Would you pay for this? What's a fair price?

**Feedback collection methods**
In-app: Feedback widget on every page (powered by Canny or UserVoice), NPS survey after 10 completed workouts, feature request voting board, bug report form. External: Monthly user interviews (5-10 users), quarterly cohort analysis emails asking for feedback, support email monitoring for pain points, social media listening (Reddit, Twitter/X). Post-workout prompt: "How was this workout?" with 1-5 stars plus optional comment.

**Analytics you'll track**
Acquisition: Sign-ups by source, conversion rate from landing page. Activation: Onboarding completion rate, time to first workout, first workout completion. Engagement: DAU/WAU/MAU, workouts per week, session duration, feature usage (plan customization, exercise swaps). Retention: Day 1/7/30 retention, churn rate, streak lengths. Revenue: Trial-to-paid conversion, MRR, LTV. Product: Most/least used features, error rates, page load times. Tools: Mixpanel for events, PostHog for session recordings.

**How will you close the feedback loop?**
Weekly sprint planning prioritizes top 3 user requests from feedback board. Changelog posted in-app and emailed to users showing "You asked, we built" with credit to requesters. Reply to every feedback submission within 48 hours acknowledging receipt. Monthly "Behind the Scenes" email explaining what we shipped and why based on user feedback. Track feature requests in public roadmap (Canny) so users see status. Analytics reviewed weekly to identify drop-off points, then run targeted user interviews to understand why.


### Phase 10: Pricing & Monetisation UX

**Which pricing model fits your value delivery?**
Subscription-based recurring revenue. Monthly ($9.99/month) or annual ($79/year - 34% savings). Value delivery aligns with ongoing usage: users get continuous access to workout plans, progress tracking, and regular feature updates. Subscription makes sense because fitness is a continuous journey, not a one-time purchase. No freemium tier initially to avoid complexity - just 14-day free trial with full access.

**Pricing tiers you're considering**
Single tier for MVP simplicity: Pro ($9.99/month or $79/year) includes all features - unlimited workout plans, exercise library, progress tracking, goal setting, streak tracking. Future consideration: Free tier (1 pre-built plan, basic tracking, ads) and Premium tier ($14.99/month - AI form analysis, nutrition tracking, 1-on-1 coaching). Start simple, add tiers based on user feedback and willingness to pay data.

**When should users see pricing?**
Transparent from start - pricing page linked in header and footer. During onboarding: mention free trial after quiz, before showing first workout plan ("Your 14-day trial starts now, no card required"). On day 10 of trial: gentle reminder email "4 days left in your trial". Day 13: in-app banner "Trial ends tomorrow - subscribe to keep your progress". Clear value-first approach: let users experience the product before asking for payment.

**Upgrade prompt strategy**
Context-aware prompts at value moments: After completing 3rd workout ("You're building a streak! Subscribe to keep going"), when viewing progress dashboard ("Unlock unlimited history with Pro"), before workout plan customization ("Customize your plan with Pro"). Never interrupt mid-workout. Email sequence: Day 10 (trial reminder), Day 13 (last chance), Day 15 post-trial (see what you're missing). In-app: subtle banner at top, not blocking modals. Focus on value unlocked, not features lost.

**Pricing page features**
Clean, single-page design. Annual vs monthly toggle prominently showing savings. Social proof: "Join 10,000+ users transforming their fitness". Feature list with icons: unlimited plans, progress tracking, goal setting, no ads. FAQ section: Can I cancel anytime? (Yes), What happens to my data? (Keeps for 30 days). Testimonial carousel from beta users. Money-back guarantee: 30 days, no questions asked. CTA: "Start 14-day free trial" (not "Buy now").

**International customer considerations**
Currency localization via Stripe - show prices in user's local currency (USD, GBP, EUR initially). EU VAT compliance automated through Stripe Tax. Pricing adjusted by purchasing power parity for developing markets (e.g., $4.99/month in India). Payment methods: credit/debit cards globally, Apple Pay, Google Pay, regional methods (iDEAL in Netherlands, SEPA in EU). No region-locking of features. Support email responses within 24 hours across time zones.


### Phase 11: Launch Readiness & Analytics

**Analytics platform**
Mixpanel for event tracking and user behavior analysis. Key events: signup, onboarding_completed, workout_started, workout_completed, plan_customized, subscription_created. Cohort analysis for retention tracking. PostHog for session recordings and heatmaps to identify UX friction. Google Analytics 4 for basic traffic metrics. Stripe Dashboard for revenue analytics. Custom dashboard combining all sources for weekly review meetings.

**Error tracking & monitoring**
Sentry for error tracking and crash reporting with source maps for production debugging. Alerts via Slack for critical errors affecting >10 users. Vercel Analytics for performance monitoring (Core Web Vitals, page load times). Supabase logs for database query performance and auth issues. PagerDuty for on-call rotation if critical services down. Weekly error review to prioritize bug fixes. Target: <0.1% error rate, <100ms API response time p95.

**Uptime & SLA commitments**
Target 99.9% uptime (max 43 minutes downtime/month). Monitoring via UptimeRobot checking /api/health endpoint every 5 minutes from multiple regions. Status page at status.gymapppro.com (powered by Statuspage.io or custom) showing real-time service health. No formal SLA for MVP, but internal goal: resolve critical issues within 2 hours, major bugs within 24 hours. Planned maintenance windows announced 48 hours in advance via email and in-app banner.

**Compliance & security requirements**
GDPR compliance: Privacy policy, cookie consent banner, data export/deletion on request within 30 days. CCPA compliance for California users. Security: HTTPS everywhere, Supabase RLS for data isolation, password hashing via bcrypt, rate limiting on auth endpoints, CSP headers, XSS protection. Data encryption at rest (Supabase default) and in transit (TLS 1.3). Regular dependency updates via Dependabot. No PII in logs. Terms of Service and Privacy Policy reviewed by lawyer before launch.

**Scaling preparation**
Infrastructure: Vercel auto-scales frontend, Supabase handles database scaling up to 100k users without changes. Database indexes on user_id, created_at for fast queries. Caching strategy: Redis for workout plan templates (rarely change), SWR for client-side data caching. CDN for static assets and images. Load testing via k6 before launch simulating 1000 concurrent users. Bottleneck mitigation: Async processing for heavy tasks (progress reports) via Supabase Edge Functions queue. Plan to handle 10k users month 1, 100k by month 6.



## Implementation Guidelines

1. **Security First**: Implement authentication and authorization from the start
2. **Modular Design**: Break features into reusable components
3. **Testing**: Write tests for critical business logic
4. **Documentation**: Keep code well-documented
5. **Performance**: Optimize database queries and API responses

## Development Commands

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Run tests
npm test

# Build for production
npm run build
```

---

*Generated with SaaS Blueprint Generator on 10/9/2025*
