# Phase 2: Core Product Assumptions (CPA Layer)

Document assumptions about growth, compliance, uptime, and customer expectations

**Estimated Time:** 20 minutes

## Guidelines

Be specific about your target audience. "Everyone" is not a valid target market.

## Questions & Answers

### 1. What type of data will you handle and which regulations apply?

Data types: Personal (names, emails, profile photos), Health (body measurements, workout stats, progress photos). Regulations: GDPR compliance needed for EU users, general data privacy standards. Data storage: Any region, but EU users' data must stay in EU. No HIPAA required as we're fitness tracking not medical device

---

### 2. Who's your initial target and what integrations do they need?

Initial target: Self-serve fitness enthusiasts and small gym owners (SMBs). No single-tenant deployments initially. Integrations needed: Social login (Google, Apple), Fitness tracker APIs (Apple Health, Google Fit, Fitbit), Payment processing (Stripe), Optional: Strava, MyFitnessPal

---

### 3. How many users/organizations do you expect in Year 1? Year 3?

Year 1: 10,000 users (500 organizations like gyms/trainers). Year 3: 100,000 users (5,000 organizations). Usage will be bursty - peak hours 6-9am and 5-8pm on weekdays. Growth rate: 25% monthly for first 6 months, then 10% monthly

---

### 4. What uptime commitment and support model will you provide?

Uptime commitment: 99.5% (acceptable downtime for maintenance during off-peak hours 2-5am). Support model: Email support 9-5 EST for first year, expanding to chat support in Year 2. Scheduled maintenance windows acceptable with 48hr notice to users

---



