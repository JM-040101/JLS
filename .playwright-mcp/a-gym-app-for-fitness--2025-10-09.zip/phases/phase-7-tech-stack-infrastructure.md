# Phase 7: Tech Stack & Infrastructure

Select technologies for maintainability and growth

**Estimated Time:** 15 minutes



## Questions & Answers

### 1. What's your team situation?

Solo developer

---

### 2. Frontend preference

Next.js 14 with App Router for server components and optimal performance. React for component library, TypeScript for type safety, Tailwind CSS + shadcn/ui for styling. React Query for data fetching/caching, Zustand for lightweight state management, Framer Motion for animations. Mobile-first responsive web app initially, with React Native wrapper (Capacitor) for future native apps if needed.

---

### 3. Backend preference

Next.js API routes for simple endpoints, Supabase for backend-as-a-service (auth, database, real-time subscriptions, storage). Edge functions for custom business logic. RESTful API design for workout CRUD operations. Background jobs via Supabase Edge Functions or Vercel Cron for daily workout reminders, weekly progress summaries.

---

### 4. Database preference

PostgreSQL via Supabase for relational data (users, workouts, exercises, logs). Schema: users table, workout_plans (templates), workout_sessions (user completions), exercise_library, progress_logs. Row-level security for user data isolation. Indexes on user_id, created_at for fast queries. Real-time subscriptions for live workout updates if training with friends.

---

### 5. Hosting & deployment preference

Vercel for Next.js frontend and API routes (automatic deployments, edge network, preview branches). Supabase cloud for database and backend services. CDN via Vercel Edge for static assets and images. Environment-based deployments: development (local), staging (preview branches), production (main branch). CI/CD via GitHub Actions for automated testing before deploy.

---

### 6. Authentication approach

Supabase Auth with multiple providers: email/password (primary), Google OAuth, Apple Sign-In (for iOS users). Magic link option for passwordless login. JWT tokens with refresh token rotation. Session management via HTTP-only cookies. Password reset via email, email verification required. Rate limiting on auth endpoints to prevent abuse.

---

### 7. Payments provider

Stripe for subscription billing. Single tier pricing ($9.99/month or $79/year). Stripe Checkout for payment collection, Stripe Customer Portal for subscription management. Webhooks for real-time subscription status updates. Trial period: 14-day free trial. Payment methods: credit/debit cards, Apple Pay, Google Pay. EU VAT compliance via Stripe Tax.

---



