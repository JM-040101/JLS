# Phase 8: Database Design & Multi-Tenancy

Design schema and choose tenancy model

**Estimated Time:** 15 minutes



## Questions & Answers

### 1. What are the core resources you need to store?

Users (profiles, preferences, subscription status), Workout Plans (templates with exercises, sets, reps, rest periods), Exercise Library (name, description, muscle groups, equipment, difficulty), Workout Sessions (user's completed workouts with timestamps), Exercise Logs (individual set performance: weight, reps, RPE), Goals (target metrics like weight, strength milestones), Progress Snapshots (periodic measurements, photos), Streaks (consecutive workout days).

---

### 2. User-Organization relationship

One organization per user

---

### 3. Multi-tenancy approach

Row-level security (RLS) with user_id on all user data tables. Single shared database with PostgreSQL policies enforcing data isolation. Each user owns their workout sessions, logs, and goals. Shared exercise library (global) with user-specific custom exercises. RLS policies: users can only SELECT/UPDATE/DELETE their own rows. Future consideration: gym/trainer accounts could be multi-tenant (one gym, many members).

---

### 4. User roles needed

MVP roles: Standard User (individual fitness enthusiast with full access to their own data). Future roles: Trainer (can view client workouts, assign plans, track progress), Gym Admin (manage multiple trainers and members), Premium User (access to advanced features like AI coaching). Role-based permissions handled via Supabase Auth user metadata and RLS policies checking user.role field.

---

### 5. Data isolation requirements

Strict user data isolation via RLS policies - users cannot access other users' workout sessions, logs, or progress data. Exercise library is globally readable but only admin-writable for curated exercises. Users can create private custom exercises visible only to them. No cross-user data leakage in queries. API endpoints validate user ownership before returning data. Future: Trainers can view clients only if explicit permission granted via trainer_client relationship table.

---



