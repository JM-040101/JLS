# Phase 3: Audience & Customer Development

Define ideal customer profile and validate problem-solution fit

**Estimated Time:** 15 minutes

## Guidelines

Price based on value delivered, not cost. Research competitor pricing thoroughly.

## Questions & Answers

### 1. What specific problem are you solving?

Pain point: People struggle to stay consistent with fitness routines due to lack of structure, progress tracking, and accountability. Current solutions: Generic fitness apps lack personalization, gym memberships are expensive and intimidating, personal trainers are costly. What's broken: Most apps are either too simple (just tracking) or too complex (overwhelming), no middle ground for guided accountability

---

### 2. What's the "job to be done" for your user?

They hire our product when: They commit to getting fit but feel lost about where to start or how to progress safely. What they're accomplishing: Building a sustainable fitness habit with clear guidance and measurable progress. Success looks like: Consistent 3-4 workouts per week, visible strength/endurance improvements within 8 weeks, feeling confident in the gym

---

### 3. Who is your Ideal Customer Profile (ICP)?

Industry: Health & Fitness. Company size: Solo fitness enthusiasts (primary), Personal trainers (2-10 clients), Small gyms (11-50 members). Buyer persona: 25-45 year old professionals who value health, willing to invest in fitness tech. End user: Same as buyer - fitness-conscious individuals seeking structured workout guidance

---

### 4. Have you validated this pain with real users?

Customer interviews: 35 interviews with gym-goers and fitness enthusiasts. Key insights: 82% want guided workout plans they can customize, 71% need progress tracking with visual feedback, 65% would pay for accountability features. Prototype: Yes - built clickable Figma wireframes, tested with 12 beta users, 9/12 said they would use it daily

---



