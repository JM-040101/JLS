# Phase 1: Product Abstraction & Vision

Define the core product metaphor and primitives that will guide all development

**Estimated Time:** 15 minutes

## Guidelines

Focus on a specific, measurable problem. The clearer your problem definition, the better your solution will be.

## Questions & Answers

### 1. How should these primitives be named consistently?

Workout: UI component=WorkoutCard, Database table=workouts, API endpoint=/api/workouts
ProgressLog: UI component=ProgressEntry, Database table=progress_logs, API endpoint=/api/progress
Goal: UI component=GoalTracker, Database table=fitness_goals, API endpoint=/api/goals

---

### 2. How do your primitives relate to each other?

One-to-many: One User has many Workouts, One Workout has many Exercise Sets
Many-to-many: Users can follow multiple Trainers, Trainers can have multiple Clients
One Goal can track multiple Progress Logs

---

### 3. What's the core metaphor for your product?

Fitness Journey - like a guided trail where users progress through workouts, track milestones, and unlock achievements along their path to better health

---

### 4. What are the main "things" users will create or manipulate?

Workouts, Progress Logs, Fitness Goals, Exercise Routines, Body Measurements. Users CREATE workout plans, LOG their exercises and reps, TRACK progress photos, SET fitness goals, and SHARE achievements with friends

---

### 5. What are the possible states for your main primitive?

Workout states: Draft → Scheduled → In Progress → Completed → Archived
Actions: Create (start new workout), Start (begin session), Log (record exercises), Complete (finish workout), Archive (remove from active list)

---



