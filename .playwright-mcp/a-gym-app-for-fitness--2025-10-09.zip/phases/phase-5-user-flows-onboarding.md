# Phase 5: User Flows & Onboarding

Map the journey from awareness to activation

**Estimated Time:** 15 minutes



## Questions & Answers

### 1. How will users sign up?

Multiple Methods

---

### 2. What is the "aha moment" you want users to experience?

Completing their first workout and seeing it automatically logged on their progress dashboard with a visual streak counter showing "Day 1". The moment they realize "I don't have to figure out what to do - the plan is already here, I just need to show up and track it" creates the emotional shift from overwhelmed to empowered.

---

### 3. How will you guide new users to that aha moment?

3-step onboarding: (1) Quick quiz - 3 questions: fitness goal, experience level, workout frequency preference (2 mins). (2) Instant plan generation - show personalized weekly plan immediately with first workout highlighted "Start here today" (30 seconds). (3) Guided first workout - interactive walkthrough showing how to log sets/reps, with celebration animation on completion (10 mins). Total time to aha: under 15 minutes from signup to first completed workout.

---

### 4. What defines an "activated" user?

User has completed at least 2 workouts within their first 7 days and returned to the app on 3+ separate days. This signals they've experienced the core value loop (plan → workout → log → see progress) multiple times and are building habit formation. Secondary indicator: user has customized at least one setting (plan difficulty, workout days, exercise swap).

---

### 5. What might cause users to drop off before activation?

Friction points: Onboarding quiz too long or asks intimidating questions (weight, body fat %), workout plans feel generic or don't match stated goals, first workout is too hard/easy causing discouragement, no reminder to come back after signup, unclear how to log exercises, too many app permissions requested upfront. Timing issues: Users sign up at night but plan starts "tomorrow" with no immediate action to take.

---



