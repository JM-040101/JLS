# Phase 10: Pricing & Monetisation UX

Define pricing strategy and upgrade flows

**Estimated Time:** 15 minutes



## Questions & Answers

### 1. Which pricing model fits your value delivery?

Subscription-based recurring revenue. Monthly ($9.99/month) or annual ($79/year - 34% savings). Value delivery aligns with ongoing usage: users get continuous access to workout plans, progress tracking, and regular feature updates. Subscription makes sense because fitness is a continuous journey, not a one-time purchase. No freemium tier initially to avoid complexity - just 14-day free trial with full access.

---

### 2. Pricing tiers you're considering

Single tier for MVP simplicity: Pro ($9.99/month or $79/year) includes all features - unlimited workout plans, exercise library, progress tracking, goal setting, streak tracking. Future consideration: Free tier (1 pre-built plan, basic tracking, ads) and Premium tier ($14.99/month - AI form analysis, nutrition tracking, 1-on-1 coaching). Start simple, add tiers based on user feedback and willingness to pay data.

---

### 3. When should users see pricing?

Transparent from start - pricing page linked in header and footer. During onboarding: mention free trial after quiz, before showing first workout plan ("Your 14-day trial starts now, no card required"). On day 10 of trial: gentle reminder email "4 days left in your trial". Day 13: in-app banner "Trial ends tomorrow - subscribe to keep your progress". Clear value-first approach: let users experience the product before asking for payment.

---

### 4. Upgrade prompt strategy

Context-aware prompts at value moments: After completing 3rd workout ("You're building a streak! Subscribe to keep going"), when viewing progress dashboard ("Unlock unlimited history with Pro"), before workout plan customization ("Customize your plan with Pro"). Never interrupt mid-workout. Email sequence: Day 10 (trial reminder), Day 13 (last chance), Day 15 post-trial (see what you're missing). In-app: subtle banner at top, not blocking modals. Focus on value unlocked, not features lost.

---

### 5. Pricing page features

Clean, single-page design. Annual vs monthly toggle prominently showing savings. Social proof: "Join 10,000+ users transforming their fitness". Feature list with icons: unlimited plans, progress tracking, goal setting, no ads. FAQ section: Can I cancel anytime? (Yes), What happens to my data? (Keeps for 30 days). Testimonial carousel from beta users. Money-back guarantee: 30 days, no questions asked. CTA: "Start 14-day free trial" (not "Buy now").

---

### 6. International customer considerations

Currency localization via Stripe - show prices in user's local currency (USD, GBP, EUR initially). EU VAT compliance automated through Stripe Tax. Pricing adjusted by purchasing power parity for developing markets (e.g., $4.99/month in India). Payment methods: credit/debit cards globally, Apple Pay, Google Pay, regional methods (iDEAL in Netherlands, SEPA in EU). No region-locking of features. Support email responses within 24 hours across time zones.

---



